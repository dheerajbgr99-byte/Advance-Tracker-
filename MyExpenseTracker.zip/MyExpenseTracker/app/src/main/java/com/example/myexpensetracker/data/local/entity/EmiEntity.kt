package com.example.myexpensetracker.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "emi_records")
data class EmiEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanName: String,
    val lenderName: String,
    val totalLoanAmount: Double,
    val monthlyEmi: Double,
    val interestRate: Double,
    val totalInstallments: Int,
    val paidInstallments: Int,
    val nextDueDate: Long, // Epoch timestamp in milliseconds
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingInstallments: Int
        get() = maxOf(0, totalInstallments - paidInstallments)

    val remainingAmount: Double
        get() = remainingInstallments * monthlyEmi
}
