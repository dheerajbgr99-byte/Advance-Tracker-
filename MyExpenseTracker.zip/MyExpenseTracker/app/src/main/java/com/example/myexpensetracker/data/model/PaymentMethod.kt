package com.example.myexpensetracker.data.model

enum class PaymentMethod(val displayName: String) {
    CASH("Cash"),
    BANK("Bank Account"),
    UPI("UPI"),
    CREDIT_CARD("Credit Card"),
    OTHER("Other")
}
