package com.example.myexpensetracker.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val PrimaryTeal = Color(0xFF0F766E)
val PrimaryTealLight = Color(0xFF14B8A6)
val PrimaryTealDark = Color(0xFF115E59)

val IncomeGreen = Color(0xFF16A34A)
val IncomeGreenLight = Color(0xFF22C55E)
val ExpenseRed = Color(0xFFDC2626)
val ExpenseRedLight = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF59E0B)
