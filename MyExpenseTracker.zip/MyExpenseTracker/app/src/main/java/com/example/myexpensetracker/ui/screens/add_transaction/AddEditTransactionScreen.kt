package com.example.myexpensetracker.ui.screens.add_transaction

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.myexpensetracker.data.model.PaymentMethod
import com.example.myexpensetracker.data.model.TransactionType
import com.example.myexpensetracker.ui.viewmodel.ExpenseViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTransactionScreen(
    viewModel: ExpenseViewModel,
    transactionId: Long? = null,
    onNavigateBack: () -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var selectedCategory by remember { mutableStateOf("Food & Dining") }
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.UPI) }
    var note by remember { mutableStateOf("") }
    var dateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val expenseCategories = listOf("Food & Dining", "Groceries", "Room Rent", "Electricity Charges", "Water Charges", "Wi-Fi Bill", "Shopping", "Transport", "Entertainment", "Health", "Other")
    val incomeCategories = listOf("Salary", "Freelance", "Investment", "Gift", "Rental Income", "Other")

    val categories = if (selectedType == TransactionType.EXPENSE) expenseCategories else incomeCategories

    LaunchedEffect(transactionId) {
        if (transactionId != null) {
            val existing = viewModel.getTransactionById(transactionId)
            if (existing != null) {
                amount = existing.amount.toString()
                selectedType = existing.type
                selectedCategory = existing.category
                selectedPaymentMethod = existing.paymentMethod
                note = existing.note
                dateMillis = existing.date
            }
        }
    }

    LaunchedEffect(selectedType) {
        if (!categories.contains(selectedCategory)) {
            selectedCategory = categories.first()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (transactionId == null) "Add Transaction" else "Edit Transaction", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            TabRow(selectedTabIndex = if (selectedType == TransactionType.EXPENSE) 0 else 1) {
                Tab(
                    selected = selectedType == TransactionType.EXPENSE,
                    onClick = { selectedType = TransactionType.EXPENSE },
                    text = { Text("Expense") }
                )
                Tab(
                    selected = selectedType == TransactionType.INCOME,
                    onClick = { selectedType = TransactionType.INCOME },
                    text = { Text("Income") }
                )
            }

            OutlinedTextField(
                value = amount,
                onValueChange = { 
                    if (it.isEmpty() || it.matches(Regex("^\\d*\\.?\\d{0,2}$"))) {
                        amount = it 
                        errorMessage = null
                    }
                },
                label = { Text("Amount (₹)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = errorMessage != null
            )

            Text("Category", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            OptInFlowRow(categories, selectedCategory) { cat ->
                selectedCategory = cat
            }

            Text("Payment Method", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PaymentMethod.values().forEach { method ->
                    FilterChip(
                        selected = selectedPaymentMethod == method,
                        onClick = { selectedPaymentMethod = method },
                        label = { Text(method.displayName) }
                    )
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Note / Description (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            if (errorMessage != null) {
                Text(
                    text = errorMessage!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    val parsedAmount = amount.toDoubleOrNull()
                    if (parsedAmount == null || parsedAmount <= 0.0) {
                        errorMessage = "Please enter a valid amount greater than 0"
                        return@Button
                    }
                    if (transactionId == null) {
                        viewModel.insertTransaction(
                            amount = parsedAmount,
                            type = selectedType,
                            category = selectedCategory,
                            paymentMethod = selectedPaymentMethod,
                            date = dateMillis,
                            note = note.trim(),
                            onSuccess = onNavigateBack
                        )
                    } else {
                        viewModel.updateTransaction(
                            id = transactionId,
                            amount = parsedAmount,
                            type = selectedType,
                            category = selectedCategory,
                            paymentMethod = selectedPaymentMethod,
                            date = dateMillis,
                            note = note.trim(),
                            onSuccess = onNavigateBack
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (transactionId == null) "Save Transaction" else "Update Transaction")
            }
        }
    }
}

@Composable
private fun OptInFlowRow(
    categories: List<String>,
    selectedCategory: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        categories.chunked(3).forEach { rowCats ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                rowCats.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { onSelect(cat) },
                        label = { Text(cat, maxLines = 1) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
