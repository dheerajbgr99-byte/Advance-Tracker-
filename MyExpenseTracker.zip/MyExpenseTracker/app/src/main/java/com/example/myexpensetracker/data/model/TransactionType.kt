package com.example.myexpensetracker.data.model

enum class TransactionType {
    INCOME,
    EXPENSE
}
