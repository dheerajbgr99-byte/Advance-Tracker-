package com.example.myexpensetracker.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myexpensetracker.data.local.entity.BudgetEntity
import com.example.myexpensetracker.data.local.entity.EmiEntity
import com.example.myexpensetracker.data.local.entity.FixedExpenseEntity
import com.example.myexpensetracker.data.local.entity.TransactionEntity
import com.example.myexpensetracker.data.model.Frequency
import com.example.myexpensetracker.data.model.PaymentMethod
import com.example.myexpensetracker.data.model.TransactionType
import com.example.myexpensetracker.data.repository.TransactionRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class DashboardUiState(
    val totalIncome: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val currentBalance: Double = 0.0,
    val totalSavings: Double = 0.0,
    val thisMonthIncome: Double = 0.0,
    val thisMonthExpenses: Double = 0.0,
    val currentMonthBudget: Double? = null,
    val budgetUsedPercent: Int = 0,
    val budgetRemaining: Double = 0.0,
    val isBudgetWarning: Boolean = false,
    val isBudgetExceeded: Boolean = false,
    val recentTransactions: List<TransactionEntity> = emptyList(),
    val upcomingFixedExpenses: List<FixedExpenseEntity> = emptyList(),
    val upcomingEmis: List<EmiEntity> = emptyList()
)

class ExpenseViewModel(private val repository: TransactionRepository) : ViewModel() {

    private val currentMonthYear: String
        get() = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date())

    val allTransactions = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFixedExpenses = repository.allFixedExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allEmis = repository.allEmis
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentBudget = repository.getBudgetForMonth(currentMonthYear)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val dashboardUiState: StateFlow<DashboardUiState> = combine(
        combine(
            repository.getTotalByType(TransactionType.INCOME),
            repository.getTotalByType(TransactionType.EXPENSE),
            repository.getRecentTransactions(5)
        ) { income, expense, recent -> Triple(income ?: 0.0, expense ?: 0.0, recent) },
        combine(
            allTransactions,
            currentBudget,
            allFixedExpenses,
            allEmis
        ) { all, budget, fixedList, emiList ->
            DashboardData(all, budget, fixedList, emiList)
        }
    ) { totals, data ->
        val totalInc = totals.first
        val totalExp = totals.second
        val recent = totals.third
        val all = data.all
        val budget = data.budget
        val fixedList = data.fixedList
        val emiList = data.emiList

        val balance = totalInc - totalExp
        val savings = if (balance > 0) balance else 0.0

        val calendar = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val monthStart = calendar.timeInMillis
        calendar.add(Calendar.MONTH, 1)
        val monthEnd = calendar.timeInMillis - 1

        val thisMonthInc = all.filter { it.type == TransactionType.INCOME && it.date in monthStart..monthEnd }.sumOf { it.amount }
        val thisMonthExp = all.filter { it.type == TransactionType.EXPENSE && it.date in monthStart..monthEnd }.sumOf { it.amount }

        val budgetAmt = budget?.amount
        var usedPercent = 0
        var remaining = 0.0
        var warning = false
        var exceeded = false

        if (budgetAmt != null && budgetAmt > 0) {
            usedPercent = ((thisMonthExp / budgetAmt) * 100).toInt()
            remaining = budgetAmt - thisMonthExp
            warning = usedPercent in 80..100
            exceeded = usedPercent > 100
        }

        DashboardUiState(
            totalIncome = totalInc,
            totalExpenses = totalExp,
            currentBalance = balance,
            totalSavings = savings,
            thisMonthIncome = thisMonthInc,
            thisMonthExpenses = thisMonthExp,
            currentMonthBudget = budgetAmt,
            budgetUsedPercent = usedPercent,
            budgetRemaining = remaining,
            isBudgetWarning = warning,
            isBudgetExceeded = exceeded,
            recentTransactions = recent,
            upcomingFixedExpenses = fixedList.take(3),
            upcomingEmis = emiList.filter { it.paidInstallments < it.totalInstallments }.take(2)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    fun setMonthlyBudget(amount: Double) {
        viewModelScope.launch {
            repository.setBudget(currentMonthYear, amount)
        }
    }

    fun insertTransaction(amount: Double, type: TransactionType, category: String, paymentMethod: PaymentMethod, date: Long, note: String, onSuccess: () -> Unit = {}) {
        if (amount <= 0) return
        viewModelScope.launch {
            repository.insertTransaction(TransactionEntity(amount = amount, type = type, category = category, paymentMethod = paymentMethod, date = date, note = note))
            onSuccess()
        }
    }

    fun updateTransaction(id: Long, amount: Double, type: TransactionType, category: String, paymentMethod: PaymentMethod, date: Long, note: String, onSuccess: () -> Unit = {}) {
        if (amount <= 0) return
        viewModelScope.launch {
            repository.updateTransaction(TransactionEntity(id = id, amount = amount, type = type, category = category, paymentMethod = paymentMethod, date = date, note = note))
            onSuccess()
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch { repository.deleteTransaction(transaction) }
    }

    // Fixed Expense Actions
    fun insertFixedExpense(title: String, amount: Double, category: String, dueDate: Long, frequency: Frequency) {
        if (amount <= 0 || title.isBlank()) return
        viewModelScope.launch {
            repository.insertFixedExpense(FixedExpenseEntity(title = title, amount = amount, category = category, dueDate = dueDate, frequency = frequency))
        }
    }

    fun markFixedExpensePaid(expense: FixedExpenseEntity) {
        viewModelScope.launch {
            // Record payment as transaction
            repository.insertTransaction(
                TransactionEntity(
                    amount = expense.amount,
                    type = TransactionType.EXPENSE,
                    category = expense.category,
                    paymentMethod = PaymentMethod.UPI,
                    date = System.currentTimeMillis(),
                    note = "Fixed: ${expense.title}"
                )
            )
            // Advance next due date
            val calendar = Calendar.getInstance().apply { timeInMillis = expense.dueDate }
            when (expense.frequency) {
                Frequency.MONTHLY -> calendar.add(Calendar.MONTH, 1)
                Frequency.WEEKLY -> calendar.add(Calendar.DAY_OF_YEAR, 7)
                Frequency.YEARLY -> calendar.add(Calendar.YEAR, 1)
            }
            repository.updateFixedExpense(
                expense.copy(
                    isPaid = true,
                    lastPaidDate = System.currentTimeMillis(),
                    dueDate = calendar.timeInMillis
                )
            )
        }
    }

    fun deleteFixedExpense(expense: FixedExpenseEntity) {
        viewModelScope.launch { repository.deleteFixedExpense(expense) }
    }

    // EMI Actions
    fun insertEmi(loanName: String, lenderName: String, totalAmount: Double, monthlyEmi: Double, rate: Double, totalInst: Int, paidInst: Int, dueDate: Long) {
        if (totalAmount <= 0 || monthlyEmi <= 0) return
        viewModelScope.launch {
            repository.insertEmi(
                EmiEntity(
                    loanName = loanName,
                    lenderName = lenderName,
                    totalLoanAmount = totalAmount,
                    monthlyEmi = monthlyEmi,
                    interestRate = rate,
                    totalInstallments = totalInst,
                    paidInstallments = paidInst,
                    nextDueDate = dueDate
                )
            )
        }
    }

    fun markEmiInstallmentPaid(emi: EmiEntity) {
        if (emi.paidInstallments >= emi.totalInstallments) return
        viewModelScope.launch {
            repository.insertTransaction(
                TransactionEntity(
                    amount = emi.monthlyEmi,
                    type = TransactionType.EXPENSE,
                    category = "Bills & Utilities",
                    paymentMethod = PaymentMethod.BANK,
                    date = System.currentTimeMillis(),
                    note = "EMI: ${emi.loanName} (${emi.paidInstallments + 1}/${emi.totalInstallments})"
                )
            )
            val calendar = Calendar.getInstance().apply { timeInMillis = emi.nextDueDate }
            calendar.add(Calendar.MONTH, 1)
            repository.updateEmi(
                emi.copy(
                    paidInstallments = emi.paidInstallments + 1,
                    nextDueDate = calendar.timeInMillis
                )
            )
        }
    }

    fun deleteEmi(emi: EmiEntity) {
        viewModelScope.launch { repository.deleteEmi(emi) }
    }

    fun clearAllData() {
        viewModelScope.launch { repository.clearAll() }
    }

    suspend fun getTransactionById(id: Long) = repository.getTransactionById(id)
}

private data class DashboardData(
    val all: List<TransactionEntity>,
    val budget: BudgetEntity?,
    val fixedList: List<FixedExpenseEntity>,
    val emiList: List<EmiEntity>
)
