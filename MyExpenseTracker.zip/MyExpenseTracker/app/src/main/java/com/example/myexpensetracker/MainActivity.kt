package com.example.myexpensetracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.myexpensetracker.ui.navigation.Screen
import com.example.myexpensetracker.ui.screens.add_transaction.AddEditTransactionScreen
import com.example.myexpensetracker.ui.screens.dashboard.DashboardScreen
import com.example.myexpensetracker.ui.screens.fixed_emi.FixedAndEmiScreen
import com.example.myexpensetracker.ui.screens.reports.ReportsScreen
import com.example.myexpensetracker.ui.screens.settings.SettingsScreen
import com.example.myexpensetracker.ui.screens.transactions.TransactionListScreen
import com.example.myexpensetracker.ui.theme.MyExpenseTrackerTheme
import com.example.myexpensetracker.ui.viewmodel.ExpenseViewModel
import com.example.myexpensetracker.ui.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {

    private val expenseViewModel: ExpenseViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val app = application as ExpenseTrackerApplication
                @Suppress("UNCHECKED_CAST")
                return ExpenseViewModel(app.repository) as T
            }
        }
    }

    private val settingsViewModel: SettingsViewModel by viewModels {
        object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val app = application as ExpenseTrackerApplication
                @Suppress("UNCHECKED_CAST")
                return SettingsViewModel(app.userPreferencesRepository) as T
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val themeMode by settingsViewModel.themeMode.collectAsState()
            val selectedCurrency by settingsViewModel.selectedCurrency.collectAsState()

            val isDarkTheme = when (themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            MyExpenseTrackerTheme(darkTheme = isDarkTheme) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppNavigation(
                        expenseViewModel = expenseViewModel,
                        settingsViewModel = settingsViewModel,
                        currencyCode = selectedCurrency
                    )
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    expenseViewModel: ExpenseViewModel,
    settingsViewModel: SettingsViewModel,
    currencyCode: String
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = listOf(
        Triple(Screen.Dashboard.route, "Dashboard", Icons.Default.Dashboard),
        Triple(Screen.Transactions.route, "Transactions", Icons.Default.List),
        Triple(Screen.FixedAndEmi.route, "Fixed & EMI", Icons.Default.CalendarToday),
        Triple(Screen.Reports.route, "Reports", Icons.Default.PieChart),
        Triple(Screen.Settings.route, "Settings", Icons.Default.Settings)
    )

    val showBottomBar = currentRoute in bottomNavItems.map { it.first }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { (route, label, icon) ->
                        NavigationBarItem(
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) },
                            selected = currentRoute == route,
                            onClick = {
                                navController.navigate(route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    viewModel = expenseViewModel,
                    currencyCode = currencyCode,
                    onNavigateToAdd = { navController.navigate(Screen.AddTransaction.createRoute()) },
                    onNavigateToTransactions = { navController.navigate(Screen.Transactions.route) },
                    onEditTransaction = { id -> navController.navigate(Screen.AddTransaction.createRoute(id)) }
                )
            }

            composable(
                route = Screen.AddTransaction.route,
                arguments = listOf(navArgument("transactionId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getString("transactionId")?.toLongOrNull()
                AddEditTransactionScreen(
                    viewModel = expenseViewModel,
                    transactionId = id,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Transactions.route) {
                TransactionListScreen(
                    viewModel = expenseViewModel,
                    currencyCode = currencyCode,
                    onEditTransaction = { id -> navController.navigate(Screen.AddTransaction.createRoute(id)) }
                )
            }

            composable(Screen.FixedAndEmi.route) {
                FixedAndEmiScreen(
                    viewModel = expenseViewModel,
                    currencyCode = currencyCode
                )
            }

            composable(Screen.Reports.route) {
                ReportsScreen(
                    viewModel = expenseViewModel,
                    currencyCode = currencyCode
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    settingsViewModel = settingsViewModel,
                    expenseViewModel = expenseViewModel
                )
            }
        }
    }
}
