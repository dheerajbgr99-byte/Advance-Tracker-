package com.example.myexpensetracker.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.myexpensetracker.data.model.Frequency

@Entity(tableName = "fixed_expenses")
data class FixedExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val category: String,
    val dueDate: Long, // Epoch timestamp in milliseconds
    val frequency: Frequency,
    val isPaid: Boolean = false,
    val lastPaidDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
