package com.example.myexpensetracker.ui.screens.fixed_emi

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.myexpensetracker.data.model.Frequency
import com.example.myexpensetracker.ui.viewmodel.ExpenseViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FixedAndEmiScreen(
    viewModel: ExpenseViewModel,
    currencyCode: String = "INR"
) {
    var selectedTab by remember { mutableStateOf(0) }
    val fixedExpenses by viewModel.allFixedExpenses.collectAsState()
    val emiRecords by viewModel.allEmis.collectAsState()

    var showAddFixedDialog by remember { mutableStateOf(false) }
    var showAddEmiDialog by remember { mutableStateOf(false) }

    val currencyFormatter = NumberFormat.getCurrencyInstance(
        if (currencyCode == "INR") Locale("en", "IN") else Locale.getDefault()
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Fixed Expenses & Loans", fontWeight = FontWeight.Bold) },
                actions = {
                    Button(
                        onClick = { if (selectedTab == 0) showAddFixedDialog = true else showAddEmiDialog = true },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (selectedTab == 0) "+ Add Bill" else "+ Add EMI")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { if (selectedTab == 0) showAddFixedDialog = true else showAddEmiDialog = true },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add New")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Fixed Expenses") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Loan EMIs") })
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTab == 0) {
                // Fixed Expenses List
                if (fixedExpenses.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No recurring fixed expenses added yet.")
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = { showAddFixedDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Add Room Rent, Electricity or Bill")
                            }
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(fixedExpenses, key = { it.id }) { item ->
                            val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(item.title, fontWeight = FontWeight.SemiBold)
                                        Text("${item.category} · ${item.frequency.displayName}", style = MaterialTheme.typography.bodySmall)
                                        Text("Due: ${dateFormat.format(Date(item.dueDate))}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            currencyFormatter.format(item.amount),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                        IconButton(onClick = { viewModel.markFixedExpensePaid(item) }) {
                                            Icon(Icons.Default.Check, contentDescription = "Mark Paid")
                                        }
                                        IconButton(onClick = { viewModel.deleteFixedExpense(item) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // EMI List
                if (emiRecords.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No loan EMI records added yet.")
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = { showAddEmiDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("+ Add Bike Loan, Phone or EMI")
                            }
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(emiRecords, key = { it.id }) { emi ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(emi.loanName, fontWeight = FontWeight.Bold)
                                            Text("Lender: ${emi.lenderName}", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text(
                                            currencyFormatter.format(emi.monthlyEmi) + "/mo",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "Remaining: ${emi.remainingInstallments} installments (${currencyFormatter.format(emi.remainingAmount)})",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = (emi.paidInstallments.toFloat() / emi.totalInstallments.toFloat()),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(
                                            onClick = { viewModel.markEmiInstallmentPaid(emi) },
                                            enabled = emi.paidInstallments < emi.totalInstallments
                                        ) {
                                            Text("Pay Installment")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DIALOG: ADD FIXED EXPENSE
    if (showAddFixedDialog) {
        var title by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Room Rent") }

        AlertDialog(
            onDismissRequest = { showAddFixedDialog = false },
            title = { Text("Add Fixed Bill / Expense") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Bill Title (e.g. Room Rent)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("Amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category (e.g. Room Rent, Electricity)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val parsedAmt = amount.toDoubleOrNull()
                    if (title.isNotBlank() && parsedAmt != null && parsedAmt > 0) {
                        viewModel.insertFixedExpense(
                            title = title.trim(),
                            amount = parsedAmt,
                            category = category.trim().ifEmpty { "Fixed Bills" },
                            dueDate = System.currentTimeMillis() + 5 * 86400000L,
                            frequency = Frequency.MONTHLY
                        )
                        showAddFixedDialog = false
                    }
                }) {
                    Text("Save Bill")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddFixedDialog = false }) { Text("Cancel") }
            }
        )
    }

    // DIALOG: ADD EMI RECORD
    if (showAddEmiDialog) {
        var loanName by remember { mutableStateOf("") }
        var lenderName by remember { mutableStateOf("") }
        var totalAmount by remember { mutableStateOf("") }
        var monthlyEmi by remember { mutableStateOf("") }
        var totalMonths by remember { mutableStateOf("12") }

        AlertDialog(
            onDismissRequest = { showAddEmiDialog = false },
            title = { Text("Add New Loan EMI") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = loanName,
                        onValueChange = { loanName = it },
                        label = { Text("Loan Name (e.g. Bike EMI)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = lenderName,
                        onValueChange = { lenderName = it },
                        label = { Text("Lender / Bank Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = monthlyEmi,
                            onValueChange = { monthlyEmi = it },
                            label = { Text("Monthly EMI") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = totalAmount,
                            onValueChange = { totalAmount = it },
                            label = { Text("Total Loan") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = totalMonths,
                        onValueChange = { totalMonths = it },
                        label = { Text("Total Months") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val emiAmt = monthlyEmi.toDoubleOrNull()
                    val totalAmt = totalAmount.toDoubleOrNull()
                    val months = totalMonths.toIntOrNull() ?: 12
                    if (loanName.isNotBlank() && emiAmt != null && emiAmt > 0 && totalAmt != null && totalAmt > 0) {
                        viewModel.insertEmi(
                            loanName = loanName.trim(),
                            lenderName = lenderName.trim().ifEmpty { "Bank" },
                            totalAmount = totalAmt,
                            monthlyEmi = emiAmt,
                            rate = 8.5,
                            totalInst = months,
                            paidInst = 0,
                            dueDate = System.currentTimeMillis() + 10 * 86400000L
                        )
                        showAddEmiDialog = false
                    }
                }) {
                    Text("Save EMI")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddEmiDialog = false }) { Text("Cancel") }
            }
        )
    }
}
