package com.example.myexpensetracker.ui.screens.fixed_emi

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.myexpensetracker.ui.viewmodel.ExpenseViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FixedAndEmiScreen(
    viewModel: ExpenseViewModel,
    currencyCode: String = "INR"
) {
    var selectedTab by remember { mutableStateOf(0) }
    val fixedExpenses by viewModel.allFixedExpenses.collectAsState()
    val emiRecords by viewModel.allEmis.collectAsState()

    val currencyFormatter = NumberFormat.getCurrencyInstance(
        if (currencyCode == "INR") Locale("en", "IN") else Locale.getDefault()
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Fixed Expenses & Loans", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Fixed Expenses") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Loan EMIs") })
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTab == 0) {
                // Fixed Expenses List
                if (fixedExpenses.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No recurring fixed expenses added yet.")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(fixedExpenses, key = { it.id }) { item ->
                            val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(item.title, fontWeight = FontWeight.SemiBold)
                                        Text("${item.category} · ${item.frequency.displayName}", style = MaterialTheme.typography.bodySmall)
                                        Text("Due: ${dateFormat.format(Date(item.dueDate))}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            currencyFormatter.format(item.amount),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                        IconButton(onClick = { viewModel.markFixedExpensePaid(item) }) {
                                            Icon(Icons.Default.Check, contentDescription = "Mark Paid")
                                        }
                                        IconButton(onClick = { viewModel.deleteFixedExpense(item) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // EMI List
                if (emiRecords.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No loan EMI records added yet.")
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(emiRecords, key = { it.id }) { emi ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(emi.loanName, fontWeight = FontWeight.Bold)
                                            Text("Lender: ${emi.lenderName}", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text(
                                            currencyFormatter.format(emi.monthlyEmi) + "/mo",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "Remaining: ${emi.remainingInstallments} installments (${currencyFormatter.format(emi.remainingAmount)})",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = (emi.paidInstallments.toFloat() / emi.totalInstallments.toFloat()),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(
                                            onClick = { viewModel.markEmiInstallmentPaid(emi) },
                                            enabled = emi.paidInstallments < emi.totalInstallments
                                        ) {
                                            Text("Pay Installment")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
