package com.example.myexpensetracker.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Dashboard : Screen("dashboard", "Dashboard")
    object Transactions : Screen("transactions", "Transactions")
    object FixedAndEmi : Screen("fixed_emi", "Fixed & EMI")
    object Reports : Screen("reports", "Reports")
    object Settings : Screen("settings", "Settings")
    object AddTransaction : Screen("add_transaction?transactionId={transactionId}", "Add Transaction") {
        fun createRoute(transactionId: Long? = null) = 
            if (transactionId != null) "add_transaction?transactionId=$transactionId" else "add_transaction"
    }
}
