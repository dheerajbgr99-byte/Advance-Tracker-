package com.example.myexpensetracker.data.backup

import android.content.Context
import android.net.Uri
import com.example.myexpensetracker.data.local.ExpenseDatabase
import com.example.myexpensetracker.data.local.entity.BudgetEntity
import com.example.myexpensetracker.data.local.entity.EmiEntity
import com.example.myexpensetracker.data.local.entity.FixedExpenseEntity
import com.example.myexpensetracker.data.local.entity.TransactionEntity
import com.example.myexpensetracker.data.model.Frequency
import com.example.myexpensetracker.data.model.PaymentMethod
import com.example.myexpensetracker.data.model.TransactionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object BackupManager {

    suspend fun exportBackup(context: Context, database: ExpenseDatabase, uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()
            root.put("version", 2)
            root.put("appName", "My Expense Tracker")
            root.put("exportDate", System.currentTimeMillis())

            // Export Transactions
            val transactions = database.transactionDao().getAllTransactions().first()
            val txArray = JSONArray()
            transactions.forEach { tx ->
                val obj = JSONObject().apply {
                    put("id", tx.id)
                    put("amount", tx.amount)
                    put("type", tx.type.name)
                    put("category", tx.category)
                    put("paymentMethod", tx.paymentMethod.name)
                    put("date", tx.date)
                    put("note", tx.note)
                    put("createdAt", tx.createdAt)
                }
                txArray.put(obj)
            }
            root.put("transactions", txArray)

            // Export Budgets
            val budgets = database.budgetDao().getAllBudgetsList()
            val budgetArray = JSONArray()
            budgets.forEach { b ->
                budgetArray.put(JSONObject().apply {
                    put("monthYear", b.monthYear)
                    put("amount", b.amount)
                    put("updatedAt", b.updatedAt)
                })
            }
            root.put("budgets", budgetArray)

            // Export Fixed Expenses
            val fixed = database.fixedExpenseDao().getAllFixedExpensesList()
            val fixedArray = JSONArray()
            fixed.forEach { f ->
                fixedArray.put(JSONObject().apply {
                    put("title", f.title)
                    put("amount", f.amount)
                    put("category", f.category)
                    put("dueDate", f.dueDate)
                    put("frequency", f.frequency.name)
                    put("isPaid", f.isPaid)
                    put("lastPaidDate", f.lastPaidDate ?: 0L)
                })
            }
            root.put("fixedExpenses", fixedArray)

            // Export EMIs
            val emis = database.emiDao().getAllEmisList()
            val emiArray = JSONArray()
            emis.forEach { e ->
                emiArray.put(JSONObject().apply {
                    put("loanName", e.loanName)
                    put("lenderName", e.lenderName)
                    put("totalLoanAmount", e.totalLoanAmount)
                    put("monthlyEmi", e.monthlyEmi)
                    put("interestRate", e.interestRate)
                    put("totalInstallments", e.totalInstallments)
                    put("paidInstallments", e.paidInstallments)
                    put("nextDueDate", e.nextDueDate)
                })
            }
            root.put("emiRecords", emiArray)

            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(root.toString(2).toByteArray(Charsets.UTF_8))
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun importBackup(context: Context, database: ExpenseDatabase, uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val content = StringBuilder()
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    var line: String? = reader.readLine()
                    while (line != null) {
                        content.append(line)
                        line = reader.readLine()
                    }
                }
            }

            val root = JSONObject(content.toString())
            if (!root.has("transactions")) {
                return@withContext Result.failure(IllegalArgumentException("Invalid backup file: transactions array missing."))
            }

            val txArray = root.getJSONArray("transactions")
            val newTransactions = mutableListOf<TransactionEntity>()
            for (i in 0 until txArray.length()) {
                val obj = txArray.getJSONObject(i)
                newTransactions.add(
                    TransactionEntity(
                        amount = obj.getDouble("amount"),
                        type = TransactionType.valueOf(obj.getString("type")),
                        category = obj.getString("category"),
                        paymentMethod = PaymentMethod.valueOf(obj.getString("paymentMethod")),
                        date = obj.getLong("date"),
                        note = obj.optString("note", "")
                    )
                )
            }

            // Restore into database inside a transaction
            database.transactionDao().clearAllTransactions()
            database.transactionDao().insertAll(newTransactions)

            // Optional budgets restoration
            if (root.has("budgets")) {
                val budgetArray = root.getJSONArray("budgets")
                val newBudgets = mutableListOf<BudgetEntity>()
                for (i in 0 until budgetArray.length()) {
                    val obj = budgetArray.getJSONObject(i)
                    newBudgets.add(
                        BudgetEntity(
                            monthYear = obj.getString("monthYear"),
                            amount = obj.getDouble("amount")
                        )
                    )
                }
                database.budgetDao().clearAllBudgets()
                database.budgetDao().insertAll(newBudgets)
            }

            // Optional fixed expenses restoration
            if (root.has("fixedExpenses")) {
                val fixedArray = root.getJSONArray("fixedExpenses")
                val newFixed = mutableListOf<FixedExpenseEntity>()
                for (i in 0 until fixedArray.length()) {
                    val obj = fixedArray.getJSONObject(i)
                    newFixed.add(
                        FixedExpenseEntity(
                            title = obj.getString("title"),
                            amount = obj.getDouble("amount"),
                            category = obj.getString("category"),
                            dueDate = obj.getLong("dueDate"),
                            frequency = Frequency.valueOf(obj.getString("frequency")),
                            isPaid = obj.optBoolean("isPaid", false)
                        )
                    )
                }
                database.fixedExpenseDao().clearAllFixedExpenses()
                database.fixedExpenseDao().insertAll(newFixed)
            }

            Result.success(newTransactions.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
