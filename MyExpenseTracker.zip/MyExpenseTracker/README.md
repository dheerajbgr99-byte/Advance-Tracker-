# My Expense Tracker — Upgraded Android Studio Project (v1.1.0)

A 100% offline personal finance management system built with **Kotlin, Jetpack Compose, Material 3, Room Database (v2), MVVM, Coroutines, and WorkManager**.

## Features Included
1. **Dashboard**: Income, Expenses, Balance, Savings, This Month breakdown, Recent transactions.
2. **Monthly Budget**: Set monthly budget, percentage progress bar, 80% warning banner, >100% exceeded alert banner.
3. **Fixed Expenses**: Title, amount, category, due date, frequency (Monthly, Weekly, Yearly), mark paid, upcoming widget.
4. **EMI Tracker**: Loan name, lender, total amount, monthly EMI, interest rate, total & paid installments, remaining calculations, upcoming widget.
5. **Reports**: Monthly breakdown, highest expense category, Jetpack Compose Canvas charts, category summary.
6. **Backup & Restore**: Storage Access Framework JSON export and validated import, confirmation dialogs, zero cloud reliance.
7. **Offline Notifications**: WorkManager reminders for upcoming fixed expenses and loan dues.
8. **Settings**: Indian Rupee (₹ INR) default currency, dark/light theme, notification toggle, clear all data.

---

## How to Build the Debug APK in Android Studio

Follow these exact steps:

1. Extract `MyExpenseTracker.zip` and open the project in **Android Studio** (Ladybug or Koala).
2. Allow Gradle to sync.
3. In Android Studio's top menu bar, click:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
4. Once compilation completes, a notification will appear at the bottom right. Click **locate**.
5. The debug APK is generated at:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

---

## How to Generate the Debug APK via Terminal (CLI)

```bash
# macOS / Linux:
./gradlew assembleDebug

# Windows:
gradlew.bat assembleDebug
```
